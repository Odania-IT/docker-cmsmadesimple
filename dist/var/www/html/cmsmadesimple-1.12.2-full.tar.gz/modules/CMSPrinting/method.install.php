<?php
if (!isset($gCms)) exit;

$this->ResetLinkTemplate();
$this->ResetPrintTemplate();
//$this->ResetPDFTemplate();
$this->ResetOverrideStyle();
//$this->CreatePermission('modifyprintingsettings',$this->Lang("permission"));
?>