<?php
$lang['use_or'] = 'Nájsť výsledky, ktoré zodpovedajú akémukoľvek slovu';
$lang['param_detailpage'] = 'Použitie iba v prípade modulov, parameter povoľuje špecifikovať odlišnú stránku detailu pre výsledky.   Použiteľné napríklad keď zobrazujete detail na inej stránke ako výsledky vyhľadávania <em>(<strong>Poznámka:</strong> moduly toto môžu prepísať.)</em>';
$lang['prompt_resultpage'] = 'Stránka pre individuálne výsledky modulu <em>(poznámka: moduly môžu toto prepísať)</em>';
$lang['search_method'] = 'Kompatibilita čitateľný adries cez metódu POST, prednastavená hodnota je GET, pre zmenu vložte do stránok značku {search search_method="post"}';
$lang['export_to_csv'] = 'Export do CSV';
$lang['prompt_savephrases'] = 'Sledovanie vyhľadávacích fráz, nie samozných slov';
$lang['word'] = 'Slovo';
$lang['count'] = 'Počet';
$lang['confirm_clearstats'] = 'Ste si istý, že chcete natrvalo odstrániť štatistiky?';
$lang['clear'] = 'Vyčistiť';
$lang['statistics'] = 'štatistiky';
$lang['param_action'] = 'Specify the mode of operation for the module.  Acceptable values are \'default\', and \'keywords\'.  The keywords action can be used to generate a comma seperated list of words suitable for use in a keywords meta tag.';
$lang['param_count'] = 'Pri použití keywords, tento parameter obmedzuje výstup na zadaný počet slov.';
$lang['param_pageid'] = 'Používa sa  iba s keywords, paramtere slúži na zobrazenie výsledkov na inej stránke (pageid) ako je formulár.';
$lang['param_inline'] = 'Ak je toto nastavené, prepíšu výsledky vyhľadávania pôvodný obsah \'search\' tagu v pôvodnom bloku. Použite toto nastavenie, ak Vaša šablóna obsahuje viacero blokov s obsahom a nechcete aby výsledky vyhľadávania prepísali preddefinovaný blok';
$lang['param_passthru'] = 'Predá vymenované parametre zadaným modulom. Formát každého z parametrov je: "passtru_MODULENAME_PARAMNAME=\'value\'" napríklad: passthru_News_detailpage=\'newsdetails\'"';
$lang['param_modules'] = 'Obmedzí výsledky vyhľadávania na hodnoty indexované v zadanom zozname modulov (oddelených čiarkov)';
$lang['searchsubmit'] = 'Odoslať';
$lang['search'] = 'Vyhľadávanie';
$lang['param_submit'] = 'Text zobrazený na tlačítku pre spustenie vyhľadávania';
$lang['param_searchtext'] = 'Text zobrazený v políčku pre vyhľadávanie';
$lang['prompt_searchtext'] = 'Výchdzí text pre vyhľadávanie';
$lang['param_resultpage'] = 'Stránka pre zobrazenie výsledkov hľadania. Môže to byť buď alias stránky alebo id. Používa sa nato, aby bolo možné zobraziť výsledky vyhľadávania v inej šablóne v akej je vyhľadávací formulár';
$lang['prompt_alpharesults'] = 'Triedenie výsledkov podľa abecedy, nie na základe správnosti ako zvyčajne.';
$lang['description'] = 'Modul pre vyhľadávanie obsahu na stránkach a v iných moduloch.';
$lang['reindexallcontent'] = 'Preindexovať všetok obsah';
$lang['reindexcomplete'] = 'Preindexovanie dokončené!';
$lang['stopwords'] = 'Ukončovacie slová';
$lang['default_stopwords'] = 'Ja, ja, moja, ja, my, naše, naše, my, vy, váš, vy, sami, sami, on, on, jeho, sám, ona, jej, jej, Sama to jeho, sám, oni, je, ich, oni samy, čo, ktorý, kto, koho, to, že to, ty, ja, je, sú, bolo, bolo, je, bol, je, že sa musel, ktorá má robiť, robí, to, robiť,,,, a, ale, ak je, alebo preto, as, až do doby, zatiaľ čo o, u, o, u, s, o, pred, medzi, do, až v priebehu, pred, po, nad, pod, na, od, hore, dole, in, out, zapnutý, vypnutý, nad, pod, znovu, ďalej potom, raz, tu, tam, kedy, kde, prečo, ako, všetci, každý, ako každý, málo, viac, najviac, ostatné, niektoré, ako napríklad, nie, ani nie, len, vlastné, rovnako tak, ako tiež veľmiUndo edits';
$lang['prompt_resetstopwords'] = 'Nahrať';
$lang['input_resetstopwords'] = 'Načítať';
$lang['searchresultsfor'] = 'Výsledky vyhľadávania textu';
$lang['noresultsfound'] = 'Nič sa nenašlo!';
$lang['timetaken'] = 'Čas';
$lang['usestemming'] = 'Použi korene slov (iba v angličtine)';
$lang['searchtemplate'] = 'šablóna pre vyhľadávanie';
$lang['resulttemplate'] = 'šablóna pre výsledky';
$lang['submit'] = 'Odoslať';
$lang['sysdefaults'] = 'Nastaviť východzie';
$lang['searchtemplateupdated'] = 'šablóna pre vyhľadávanie bola aktualizovaná';
$lang['resulttemplateupdated'] = 'šablóna pre výsledky bola aktualizovaná';
$lang['restoretodefaultsmsg'] = 'Táto akcia obnoví východzie nastavenie šablón. Naozaj ju chete vykonať?';
$lang['options'] = 'Voľby';
$lang['eventdesc-SearchInitiated'] = 'Spustené po inicializovaní vyhľadávania.';
$lang['eventdesc-SearchCompleted'] = 'Spustené po dokončení vyhľadávania.';
$lang['eventdesc-SearchItemAdded'] = 'Spustené po zindexovaní novej položky.';
$lang['eventdesc-SearchItemDeleted'] = 'Spustené po zmazaní položky z indexu.';
$lang['eventdesc-SearchAllItemsDeleted'] = 'Spustené po zmazaní všetkých položiek indexu.';
$lang['eventhelp-SearchInitiated'] = '<p>Spustené po inicializovaní vyhľadávania.</p>
<h4>Parametre</h4>
<ol>
<li>Vyhľadávaný text.</li>
</ol>';
$lang['eventhelp-SearchCompleted'] = '<p>Spustené po dokončení vyhľadávania.</p>
<h4>Parametre</h4>
<ol>
<li>Vyhľadávaný text.</li>
<li>Zoznam výsledkov hľadania.</li>
</ol>';
$lang['eventhelp-SearchItemAdded'] = '<p>Spustené po zindexovaní novej položky.</p>
<h4>Parametre</h4>
<ol>
<li>Názov modulu.</li>
<li>Id položky.</li>
<li>Dodatočný atribút.</li>
<li>Zindexovaný a pridaný obsah.</li>
</ol>';
$lang['eventhelp-SearchItemDeleted'] = '<p>Spustené po zmazaní položky z indexu.</p>
<h4>Parametre</h4>
<ol>
<li>Názov modulu.</li>
<li>Id položky.</li>
<li>Dodatočný atribút.</li>
</ol>';
$lang['eventhelp-SearchAllItemsDeleted'] = '<p>Spustené po zmazaní všetkých položiek indexu.</p>
<h4>Parametre</h4>
<ul>
<li>Žiadne</li>
</ul>';
$lang['help'] = '<h3>Ako to funguje?</h3>
<p>Vyhľadávanie je modul pre prehľadávanie obsahu "jadra" a určitých registrovaných modulov. Zadáte text a vrátia sa relevantné, zhodujúce sa výsledky.</p>
<h3>Ako to používať?</h3>
<p>Najjednoduchší spôsob je s použitím {search} tagu (zaobaľuje module tag pre zjednodušenie zápisu). Týmto sa umiestni modul buď do šablóny, alebo na stránku a zobrazí vyhľadávací formulár. Kód môže vyzerať takto: <code>{search}</code></p>
<h4>Ako zakázať indexovanie určitého obsahu?</h4>
<p>Vyhľadávací modul nebude prehľadávať "neaktívne" stránky. Napriek tomu, v prípade, že používate modul CustomContent, alebo iný inteligentný spôsob pre zobrazenie rôzneho obsahu pre rôzne skupiny používateľov, je odporúčané zakázať prehľadávanie takýchto živých stránok. Môžete to spraviť použitím tagu <em><!-- pageAttribute: NotSearchable --></em> hocikde na stránke. Pokiaľ vyhľadávací modul nájde takýto tag na stránke, nebude indexovať jej obsah.</p>
<p>Tag <em><!-- pageAttribute: NotSearchable --></em> môže byť umiestnený aj v šablóne. V takomto prípade, žiadna zo stránok používajúca danú šablónu nebude indexovaná. Po odstránení tagu budú takéto stránky preindexované.</p>';
?>