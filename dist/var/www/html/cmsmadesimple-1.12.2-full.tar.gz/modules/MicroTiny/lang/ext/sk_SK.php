<?php
$lang['admindescription'] = 'Zredukovaná ale stále veľmi výkonná verzia editora TinyMCE WYSIWYG.';
$lang['force_blackonwhite'] = 'Vynútiť čierny text na bielom pozadí';
$lang['help_force_blackonwhite'] = 'Prinútiť editor MicroTiny, aby použil čierny text na bielom pozadí. Môže to pomôcť pri zobrazovaní textov v editore WYSIWYG v prostrediach, ktoré majú čierne pozadie a bledšie popredie.';
$lang['strip_background'] = 'Vynechať efekty CSS na pozadí';
$lang['help_strip_background'] = 'Vynechať efekty pre pozadie z dotknutých štýlopisov. Môže to pomôcť pri zobrazovaní textu v editore WYSIWYG v prostrediach s čiernym pozadím a bledším popredím';
$lang['show_statusbar'] = 'Zobraziť stavový riadok';
$lang['help_show_statusbar'] = 'Zapnúť stavový riadok v dolnej časti WYSIWYG. Použiteľné len pri administrátorskom zobrazení';
$lang['allow_resize'] = 'Povoliť zmenu veľkosti';
$lang['help_allow_resize'] = 'Povoliť zmenu veľkosti oblasti WYSIWYG. Vyžaduje, aby bol zapnutý stavový riadok.';
$lang['view_html'] = 'Zobraziť HTML';
$lang['friendlyname'] = 'WYSIWYG editor MicroTiny';
$lang['help'] = '<h3>Ako to funguje</h3>
<p>MicroTiny je malou, redukovanou verziou editora TinyMCE, ktorá bola v minulosti predvoleným editorom WYSIWYG v systéme CMS Made Simple. Neposkytuje nič viac ako len základné nástroje pre úpravy, ale stále je to výkonný nástroj na jednoduché drobné zmeny na stránkach.</p>
<p>Tento modul poskytuje iba niekoľko nastavení a je určený na sprístupnenie obmedzených funkcií pre správcov obsahu, ktorí nepoznajú jazyk HTML. Účelom je, aby títo správcovia nemohli zásadne narušiť vzhľad stránok, alebo dojmy návštevníkov zo stránky.</p>
<h3>Ako sa používa?</h3>
<p>Automaticky by sa mala zobraziť testovacia oblasť editora MicroTiny (zobrazí sa používateľom s dostatočnými oprávneniami), v časti  "Rozšírenia >> MicroTiny WYSIWYG editor&quot, v administračnej konzole systému CMSMS.</p>
</p>Aby bolo možné používať MicroTiny ako WYSIWYG editor pri úprave stránok, musí byť vybraný v používateľských nastaveniach. Prosím vyberte voľbu "MicroTiny" v sekcii pre "Výber používaného editora WYSIWYG", v sekcii "Moje nastavenia >> Nastavenia používateľa", v administračnom paneli systému CMSMS. Ostatné voľby v rôznych moduloch alebo v šablónach stránok s obsahom, a aj samotné stránky s obsahom môžu určovať, či sa pri editovaní formulárov použije iba textové pole, alebo editor WYSIWYG.</p>
<h3>O štýloch a farbách</h3>
<p>MicroTiny načítava štýlopisy pripojené k príslušnej šablóne<em>(ak nie je možné jednoducho určiť šablónu, použije sa predvolená šablóna a jej štýlopisy)</em> a odstraňuje obrázky na pozadí, aby bol text zobrazený čo najvernejšie tomu, ako bude zobrazený na webovej stránke. Ak je vo vašej téme použité tmavé pozadie spolu s obrázkami definovanými v štýloch, môže to spôsobiť problémy. V takom prípade navrhujeme vždy zahrnúť do špecifikácií pozadia aj farbu. Napríklad takto:
<pre><code>body {
 color: #eee;
 background: <span style="color: blue;">#ddd</span> url(cesta/k/obrázku.jpg);
} 
</pre></code>
<h3>O funkcii WYSIWYG vo verejnej časti stránok</h3>
<p>Občas môže byť potrebné zobraziť textovú oblasť s editorom WYSIWYG aj pre osoby, ktoré upravujú verejne prístupnú časť stránok. Ak to chcete urobiť, vykonajte tieto dva úkony <em>(úkony sa môžu pozmeniť v budúcich verziách systému CMSMS).</em>:
<ul>
  <li>Nastavte MicroTiny ako WYSIWYG pre verejnú časť stránok (Frontend) v časti "Administrátor stránky >> Všeobecné nastavenia" stránka na karte "Všeobecné nastavenia"</li>
  <li>Pridajte volanie na tag {cms_init_editor} do stránok, kde sa bude používať editor WYSIWYG. Môžete tak učiniť v hlavičke šablóny stránky, v globálnych meta-dátach, alebo v sekciách pre špecifické meta-dáta stránky. Tento tag neakceptuje žiadne ďalšie parametre.</li>
</ul>
</p>';
$lang['example'] = 'Príklad pre MicroTiny';
$lang['settings'] = 'Nastavenia';
$lang['youareintext'] = 'Ste v';
$lang['dimensions'] = 'šírka x výška';
$lang['size'] = 'Veľkosť';
$lang['filepickertitle'] = 'Výber súboru';
$lang['cmsmslinker'] = 'Nástroj na odkazy v systéme CMSMS';
$lang['tmpnotwritable'] = 'Konfiguráciu nemožno uložiť do dočasného priečinka! Prosím opravte túto voľbu!';
$lang['css_styles_text'] = 'CSS štýky';
$lang['css_styles_help'] = 'Tu uvedené názvy štýlopisov sú pridávané do rozbaľovacieho boxu v editore. Ak ponecháte pole prázdne, rozbaľovací box bude skrytý (predvolené nastavenie).';
$lang['css_styles_help2'] = 'Štýly môžu byť buď len názvami tried, alebo to môže byť názov triedy s novým zobrazovaným názvom. 
Musí byť oddelené čiarkami alebo novými riadkami.
<br/>Napríklad: mystyle1, Môj názov štýlu=mystyle2
<br/>Výsledok: rozbaľovacie menu obsahujúce 2 položky, \'mystyle1\' a \'Môj názov štýlu\', ktoré slúžia na vloženie štýlu mystyle1, a príslušného štýlu mystyle2.
<br/>Poznámka: Nekontroluje sa aktuálna existencia štýlov s uvedeným názvom. Názvy sú uvádzané bez ďalšej kontroly toho, či uvedené štýly naozaj existujú.';
$lang['usestaticconfig_text'] = 'Použiť statický konfiguračný súbor';
$lang['usestaticconfig_help'] = 'Táto voľba vygeneruje statický konfiguračný súbor namiesto dynamického. Funguje lepšie na niektorých serveroch (napríklad keď beží PHP ako CGI modul)';
$lang['allowimages_text'] = 'Povoliť obrázky';
$lang['allowimages_help'] = 'Touto voľbou zapnete tlačidlo pre obrázky na paneli nástrojov, čo umožní vloženie obrázka do obsahu';
$lang['settingssaved'] = 'Nastavenia boli uložené';
$lang['savesettings'] = 'Uložiť nastavenia';
?>